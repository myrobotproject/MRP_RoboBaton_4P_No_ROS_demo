#!/bin/sh
# =============================================================================
# X5 sc132 专用设备 现场修复脚本  (风扇不转 + SD 卡不识别)
#
#   适用范围：仅本 SDK 树 work/sc132-v1.1.2/x5-v1.1.2 出的板子
#             board_id = 0x0505 / 0x0506，DTS = x5-md-v0p2.dts
#   修复内容：只重刷 boot 分区（内含修好的设备树），不重刷 system/app/userdata
#   2026-08-18：支持两文件包；x5-fieldfix.sh 与 boot.img 放同级后直接执行。
#   用法：    ./x5-fieldfix.sh              正常修复
#             ./x5-fieldfix.sh --check      只体检，不写盘
#             ./x5-fieldfix.sh --verify     修复重启后做验收
#             ./x5-fieldfix.sh --rollback   回滚到修复前的 boot 分区
#
#   ！！ 执行期间务必保证供电稳定，写 boot 分区中途断电会导致板子起不来 ！！
# =============================================================================
set -u

SCRIPT_VER="1.1"

# ---- 目标镜像指纹（构建产物 2026-08-18，与 SDK out/ 一一对应）----------------
BR_MD5="df51ccd2b809ab85f5ceea52773ec894"    # buildroot  boot.img
BR_SIZE=12582912
JAMMY_MD5="067948c5b3b05a56093fb38724120228" # ubuntu     boot.img
JAMMY_SIZE=33554432

# ---- 路径 -------------------------------------------------------------------
SELF_DIR=$(cd "$(dirname "$0")" 2>/dev/null && pwd)
IMG_DIR="${FIELDFIX_IMG_DIR:-$SELF_DIR/images}"
WORK_DIR=/userdata/fieldfix
LOG="$WORK_DIR/fieldfix.log"

BOOT_LINK=/dev/block/platform/by-name/boot
DT_CD=/proc/device-tree/soc/hsio_apb/sdhci@35020000/cd-inverted
I2S_DRV=/sys/bus/platform/drivers/designware-i2s

# ---- 输出 -------------------------------------------------------------------
say()  { echo "$@"; [ -d "$WORK_DIR" ] && echo "[$(date '+%F %T')] $*" >>"$LOG" 2>/dev/null; }
ok()   { say "[ OK ] $*"; }
info() { say "[INFO] $*"; }
warn() { say "[WARN] $*"; }
die()  { say "[FAIL] $*"; say "[FAIL] 已中止，未对板子做任何破坏性改动。"; exit 1; }

hr()   { say "---------------------------------------------------------------"; }

# =============================================================================
# 镜像定位
# =============================================================================
select_image() {
	# 2026-08-18：现场包收敛为“脚本 + 单个 boot 镜像”同目录执行，
	# 优先找同级 boot.img，避免操作员维护 images/ 子目录。
	if [ -n "${FIELDFIX_BOOT_IMG:-}" ]; then
		case "$FIELDFIX_BOOT_IMG" in
			/*) IMG="$FIELDFIX_BOOT_IMG" ;;
			*)
				if [ -f "$FIELDFIX_BOOT_IMG" ]; then
					IMG="$FIELDFIX_BOOT_IMG"
				else
					IMG="$SELF_DIR/$FIELDFIX_BOOT_IMG"
				fi
				;;
		esac
		info "使用 FIELDFIX_BOOT_IMG 指定镜像：$IMG"
		return 0
	fi

	if [ -f "$SELF_DIR/boot.img" ]; then
		IMG="$SELF_DIR/boot.img"
		return 0
	fi

	if [ -f "$SAME_DIR_IMG" ]; then
		IMG="$SAME_DIR_IMG"
		return 0
	fi

	# 2026-08-18：兼容旧包结构；同级目录只有一个 .img 时也允许，
	# 但多个 .img 必须拒绝，避免把操作员放错的镜像静默选中。
	COUNT=0
	ONLY_IMG=""
	for CAND in "$SELF_DIR"/*.img; do
		[ -f "$CAND" ] || continue
		COUNT=$((COUNT + 1))
		ONLY_IMG="$CAND"
	done
	if [ "$COUNT" = "1" ]; then
		IMG="$ONLY_IMG"
		return 0
	fi
	[ "$COUNT" = "0" ] || die "同级目录有多个 .img，无法自动判断要刷哪个。请只保留一个 boot 镜像，或重命名为 boot.img。"

	if [ -f "$LEGACY_IMG" ]; then
		IMG="$LEGACY_IMG"
		return 0
	fi

	die "找不到 boot 镜像。请把 boot.img 和本脚本放在同一目录后执行；也可设置 FIELDFIX_BOOT_IMG=镜像路径。"
}

# =============================================================================
# 体检：把所有前置条件查清楚，任何一条不过就拒绝动盘
# =============================================================================
preflight() {
	NEED_IMAGE="${1:-yes}"
	hr
	say " X5 现场修复脚本 v$SCRIPT_VER   $(date '+%F %T')"
	# 板上没有 RTC，时钟常年停在 2000-01-01，日志时间没法和 PC 端台账对上。
	# 这里只把 PC 的时间记下来做对照，不去改板子系统时钟——板上应用可能在跑，
	# 把时间往前跳 26 年会踩到定时器。
	[ -n "${FIELDFIX_HOST_TIME:-}" ] && say " PC 端时间：$FIELDFIX_HOST_TIME （板上无 RTC，时钟不准属正常）"
	hr

	# --- root ---
	[ "$(id -u)" = "0" ] || die "必须用 root 运行。"

	# --- 板型 ---
	BOARD_ID=$(cat /sys/class/socinfo/board_id 2>/dev/null | tr -d ' \n\r')
	case "$BOARD_ID" in
		0x0505|0x0506) ok "板型 board_id = $BOARD_ID（本修复适用）" ;;
		"")  die "读不到 /sys/class/socinfo/board_id，无法确认板型，拒绝继续。" ;;
		*)   die "board_id = $BOARD_ID，不是本修复的目标板（应为 0x0505/0x0506）。
       这块板不属于本 SDK 树，刷进去会起不来。" ;;
	esac

	# --- 当前系统版本 / rootfs 类型 ---
	VER=$(cat /etc/version 2>/dev/null || cat /etc/build-info 2>/dev/null)
	[ -n "$VER" ] || die "读不到 /etc/version，无法判断 rootfs 类型。"
	info "当前系统版本：$VER"

	case "$VER" in
		*PL5.1*) ROOTFS=buildroot; SAME_DIR_IMG="$SELF_DIR/boot-buildroot.img"; LEGACY_IMG="$IMG_DIR/boot-buildroot.img"
		         WANT_MD5="$BR_MD5";    WANT_SIZE="$BR_SIZE" ;;
		*PL5.2*) ROOTFS=ubuntu;    SAME_DIR_IMG="$SELF_DIR/boot-jammy.img";     LEGACY_IMG="$IMG_DIR/boot-jammy.img"
		         WANT_MD5="$JAMMY_MD5"; WANT_SIZE="$JAMMY_SIZE" ;;
		*) die "版本串里既无 PL5.1 也无 PL5.2，认不出 rootfs 类型：$VER" ;;
	esac
	if [ "$NEED_IMAGE" != "noimage" ]; then
		select_image
		ok "rootfs 类型 = $ROOTFS，选用镜像 $(basename "$IMG")"
	else
		ok "rootfs 类型 = $ROOTFS，回滚模式不需要 boot 镜像"
	fi

	# --- boot 分区定位（按名字，不硬编码分区号）---
	[ -e "$BOOT_LINK" ] || die "找不到 $BOOT_LINK，无法安全定位 boot 分区。"
	BOOTDEV=$(readlink -f "$BOOT_LINK")
	[ -b "$BOOTDEV" ] || die "$BOOT_LINK 指向的 $BOOTDEV 不是块设备。"
	PARTSIZE=$(blockdev --getsize64 "$BOOTDEV" 2>/dev/null)
	ok "boot 分区 = $BOOTDEV  大小 = $PARTSIZE 字节"

	# --- 分区大小必须与镜像严格相等（防止 32MB 镜像写进 12MB 分区冲掉 system）---
	[ "$PARTSIZE" = "$WANT_SIZE" ] || die "boot 分区大小 $PARTSIZE 与 $ROOTFS 镜像 $WANT_SIZE 不符。
       这说明板上分区布局与本镜像不是一套，强刷会破坏相邻分区。已拒绝。"
	ok "分区大小与镜像一致，布局匹配"

	if [ "$NEED_IMAGE" != "noimage" ]; then
		# 2026-08-18：仅刷写/体检需要镜像；回滚只依赖 /userdata/fieldfix 的备份。
		[ -f "$IMG" ] || die "镜像不存在：$IMG
       请把 boot.img 和本脚本放在同一目录，或设置 FIELDFIX_BOOT_IMG=镜像路径。"
		IMGSIZE=$(wc -c <"$IMG" | tr -d ' ')
		[ "$IMGSIZE" = "$WANT_SIZE" ] || die "镜像大小异常：$IMGSIZE，应为 $WANT_SIZE（文件可能拷贝不完整）。"
		info "正在校验镜像指纹（约需数秒）..."
		IMGMD5=$(md5sum "$IMG" | cut -d' ' -f1)
		[ "$IMGMD5" = "$WANT_MD5" ] || die "镜像 md5 不对：
       实际 $IMGMD5
       期望 $WANT_MD5
       文件损坏或拿错了版本，拒绝写入。"
		ok "镜像指纹正确 $IMGMD5"
	fi

	# --- 当前 boot 分区指纹（用于幂等判断和备份命名）---
	info "正在读取当前 boot 分区指纹..."
	CURMD5=$(dd if="$BOOTDEV" bs=1M count=$((WANT_SIZE/1048576)) 2>/dev/null | md5sum | cut -d' ' -f1)
	info "当前 boot 分区 md5 = $CURMD5"
}

# =============================================================================
# 现状体检（DT/驱动层面，说明"为什么要修"）
# =============================================================================
show_symptoms() {
	hr
	say " 当前故障状态"
	hr
	if [ -e "$DT_CD" ]; then
		warn "SD ：设备树里仍有 cd-inverted  -> 插卡也认不到（需修复）"
	else
		ok   "SD ：设备树已无 cd-inverted    -> 卡槽极性正常"
	fi
	if ls "$I2S_DRV" 2>/dev/null | grep -q '320c0000'; then
		warn "风扇：dw_i2s1 已绑定并占用 pin13 -> Ubuntu 下风扇可能不转（需修复）"
	else
		ok   "风扇：dw_i2s1 未绑定            -> GPIO424 不会被抢"
	fi
}

# =============================================================================
# 备份 + 写入 + 回读校验 + 失败回滚
# =============================================================================
do_flash() {
	mkdir -p "$WORK_DIR" 2>/dev/null || die "无法创建 $WORK_DIR"

	# --- 幂等：已经是目标固件就不重复写 ---
	# 退出码分三种，让 PC 端能分清"刚修的 / 早就修好了 / 修了还没重启"：
	#   0 = 这次真写了盘，需要重启
	#   3 = 本来就是修复版，而且已经跑在修复后的内核上 —— 完全不用管
	#   4 = 本来就是修复版，但还没重启过 —— 仍需重启
	if [ "$CURMD5" = "$WANT_MD5" ]; then
		self_install
		hr
		ok "boot 分区已经是修复后的版本，无需重复刷写。"
		if [ -e "$DT_CD" ]; then
			warn "但当前运行的还是旧内核，请重启一次让修复生效。"
			hr
			exit 4
		fi
		ok "并且已经跑在修复后的内核上，这台不用再动了。"
		hr
		exit 3
	fi

	# --- 空间检查 ---
	AVAIL=$(df -k "$WORK_DIR" | awk 'NR==2{print $4}')
	NEED=$((WANT_SIZE/1024 + 2048))
	[ "$AVAIL" -ge "$NEED" ] || die "$WORK_DIR 剩余 ${AVAIL}KB，不足以存放备份（需 ${NEED}KB）。"

	# --- 备份 ---
	BAK="$WORK_DIR/boot-backup-$CURMD5.img"
	hr
	if [ -f "$BAK" ] && [ "$(md5sum "$BAK" | cut -d' ' -f1)" = "$CURMD5" ]; then
		ok "已存在有效备份：$BAK"
	else
		info "正在备份当前 boot 分区 -> $BAK"
		dd if="$BOOTDEV" of="$BAK" bs=1M count=$((WANT_SIZE/1048576)) 2>/dev/null || die "备份失败。"
		sync
		BAKMD5=$(md5sum "$BAK" | cut -d' ' -f1)
		[ "$BAKMD5" = "$CURMD5" ] || die "备份校验失败（$BAKMD5 != $CURMD5），拒绝继续写盘。"
		ok "备份完成并校验通过：$BAK"
	fi
	echo "$BAK" >"$WORK_DIR/last-backup.path"

	# --- 写入 ---
	hr
	say " 开始写入 boot 分区，请勿断电 ..."
	dd if="$IMG" of="$BOOTDEV" bs=1M 2>/dev/null || die "写入失败！原分区可能已损坏，请立即执行：
       $0 --rollback"
	sync
	echo 3 >/proc/sys/vm/drop_caches 2>/dev/null
	sync

	# --- 回读校验（drop_caches 后读的是真实介质）---
	info "正在回读校验..."
	NEWMD5=$(dd if="$BOOTDEV" bs=1M count=$((WANT_SIZE/1048576)) 2>/dev/null | md5sum | cut -d' ' -f1)
	if [ "$NEWMD5" != "$WANT_MD5" ]; then
		warn "回读校验失败（$NEWMD5 != $WANT_MD5），正在自动回滚..."
		dd if="$BAK" of="$BOOTDEV" bs=1M 2>/dev/null
		sync
		RB=$(dd if="$BOOTDEV" bs=1M count=$((WANT_SIZE/1048576)) 2>/dev/null | md5sum | cut -d' ' -f1)
		[ "$RB" = "$CURMD5" ] && die "已回滚到修复前状态，板子仍可正常启动。请检查 eMMC 健康状况后重试。"
		die "回滚也失败了！板子可能无法启动。备份文件在 $BAK，请用串口/fastboot 救援。"
	fi
	ok "回读校验通过：$NEWMD5"

	self_install

	hr
	ok "修复写入完成。"
	say ""
	say "  >>> 请现在重启板子让修复生效： reboot"
	say "  >>> 重启后执行验收：           $WORK_DIR/x5-fieldfix.sh --verify"
	hr
}

# =============================================================================
# 把脚本自己装到持久目录
#
# 为什么必须做：板上 /tmp 是 tmpfs，一重启就没了。而修复恰恰是"重启后才生效、
# 重启后才能验收"，脚本放 /tmp 等于验收时它已经把自己删了。/userdata 是真实
# 分区，重启后还在。
# =============================================================================
self_install() {
	SELF="$0"
	[ -f "$SELF" ] || return 0
	DEST="$WORK_DIR/x5-fieldfix.sh"
	if [ "$(readlink -f "$SELF")" != "$(readlink -f "$DEST" 2>/dev/null)" ]; then
		cp -f "$SELF" "$DEST" 2>/dev/null && chmod +x "$DEST" 2>/dev/null \
			&& ok "验收脚本已装到 $DEST（重启后仍可用）"
	fi
	# 留个修复凭据：/etc/version 是 rootfs 里的，只刷 boot 不会变，现场看版本号
	# 没变会以为没修上，靠这个文件说明白。
	{
		echo "fixed_at=$(date '+%F %T')   # 板上无 RTC，此时间大概率不准"
		[ -n "${FIELDFIX_HOST_TIME:-}" ] && echo "fixed_at_pc=$FIELDFIX_HOST_TIME"
		echo "script_ver=$SCRIPT_VER"
		echo "rootfs=$ROOTFS"
		echo "boot_md5_before=$CURMD5"
		echo "boot_md5_after=$WANT_MD5"
		echo "note=只刷了 boot 分区，/etc/version 属于 rootfs 不会变，这是正常的"
	} >"$WORK_DIR/fixed.info" 2>/dev/null
}

# =============================================================================
# 验收（重启后跑）
# =============================================================================
do_verify() {
	hr
	say " 修复验收  $(date '+%F %T')"
	hr
	RC=0

	if [ -f "$WORK_DIR/fixed.info" ]; then
		info "修复记录：$(grep '^fixed_at=' "$WORK_DIR/fixed.info" | cut -d= -f2-)"
	fi
	info "系统版本：$(cat /etc/version 2>/dev/null)"
	info "         ↑ 这个版本号不会变是正常的：它属于 rootfs，本次只换了 boot 分区。"

	if [ -e "$DT_CD" ]; then
		say "[FAIL] SD ：设备树里仍有 cd-inverted（修复未生效，或没重启）"; RC=1
	else
		ok "SD ：cd-inverted 已消失"
	fi

	if ls "$I2S_DRV" 2>/dev/null | grep -q '320c0000'; then
		say "[FAIL] 风扇：dw_i2s1 仍绑定，pin13 仍会被抢"; RC=1
	else
		ok "风扇：dw_i2s1 未绑定，GPIO424 不再被抢"
	fi

	# --- SD 卡实测 ---------------------------------------------------------
	# 直接读 SD 控制器的 PRESENT_STATE(0x35020024) bit16 = Card Inserted，
	# 这样能区分"槽里压根没卡"和"插了卡却认不到"——否则两种情况都只是没有
	# mmcblk1，看起来一模一样，会把没插卡误判成修复失败。
	CARD_IN=""
	if command -v devmem >/dev/null 2>&1 && [ -d /sys/class/mmc_host/mmc1 ]; then
		echo on >/sys/class/mmc_host/mmc1/device/power/control 2>/dev/null
		sleep 1
		PS=$(devmem 0x35020024 32 2>/dev/null)
		echo auto >/sys/class/mmc_host/mmc1/device/power/control 2>/dev/null
		case "$PS" in
			0x*) CARD_IN=$(( (PS & 0x10000) != 0 )) ;;
		esac
		[ -n "$PS" ] && info "SD ：控制器 PRESENT_STATE = $PS"
	fi

	if [ -b /dev/mmcblk1 ]; then
		ok "SD ：已识别到 /dev/mmcblk1，卡可用"
		info "     本系统无自动挂载，用卡需手动 mount /dev/mmcblk1p1 /mnt"
	elif [ "$CARD_IN" = "1" ]; then
		say "[FAIL] SD ：槽内有卡(bit16=1)但没出 /dev/mmcblk1 —— 仍有问题"; RC=1
	elif [ "$CARD_IN" = "0" ]; then
		info "SD ：槽内当前没有插卡(bit16=0)，本项跳过。"
		info "     要完整验证 SD，请插卡后重新执行一次 --verify。"
	else
		info "SD ：未见 /dev/mmcblk1，且读不到控制器状态，无法判断是否插卡。"
	fi

	hr
	if [ "$RC" = "0" ]; then
		ok "验收通过。"
		say ""
		say "  风扇请以【实际转不转】为准 —— gpio424/value 读回来的值在故障时也是对的，会骗人。"
	else
		say "[FAIL] 验收未通过，请确认是否已 reboot；仍不过请回传本机 $LOG"
	fi
	hr
	return $RC
}

# =============================================================================
# 回滚
# =============================================================================
do_rollback() {
	hr
	say " 回滚到修复前的 boot 分区"
	hr
	BAK=$(cat "$WORK_DIR/last-backup.path" 2>/dev/null)
	[ -n "$BAK" ] && [ -f "$BAK" ] || die "找不到备份记录（$WORK_DIR/last-backup.path），无法回滚。"
	info "使用备份：$BAK"
	EXPECT=$(echo "$BAK" | sed 's/.*boot-backup-//; s/\.img$//')
	ACT=$(md5sum "$BAK" | cut -d' ' -f1)
	[ "$ACT" = "$EXPECT" ] || die "备份文件已损坏（$ACT != $EXPECT），拒绝回滚。"

	dd if="$BAK" of="$BOOTDEV" bs=1M 2>/dev/null || die "回滚写入失败。"
	sync; echo 3 >/proc/sys/vm/drop_caches 2>/dev/null; sync
	RB=$(dd if="$BOOTDEV" bs=1M count=$((WANT_SIZE/1048576)) 2>/dev/null | md5sum | cut -d' ' -f1)
	[ "$RB" = "$EXPECT" ] || die "回滚后校验失败（$RB != $EXPECT）。"
	ok "回滚完成，请 reboot。"
	hr
}

# =============================================================================
# main
# =============================================================================
mkdir -p "$WORK_DIR" 2>/dev/null

case "${1:-}" in
	--verify)
		do_verify; exit $?
		;;
	--check)
		# 退出码与正式修复保持同一套约定：0=需要刷、3=已修好且已生效、4=已刷入待重启
		preflight; show_symptoms
		hr
		if [ "$CURMD5" != "$WANT_MD5" ]; then
			info "结论：需要刷写。去掉 --check 重新执行即可开始修复。"
			hr; exit 0
		fi
		if [ -e "$DT_CD" ]; then
			ok   "结论：boot 分区已是修复版，但还没重启过，重启一次即可生效。"
			hr; exit 4
		fi
		ok "结论：已修复且已生效，这台不用动。"
		hr; exit 3
		;;
	--rollback)
		# 注意：这里不能吞掉 preflight 的输出，否则体检失败时现场看不到原因
		preflight noimage
		do_rollback; exit $?
		;;
	"")
		preflight
		show_symptoms
		do_flash
		;;
	*)
		echo "用法: $0 [--check|--verify|--rollback]"; exit 2
		;;
esac
